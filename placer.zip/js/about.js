//about.js

$(document).ready(function(){

	$(".navi").animate({opacity:"1"},1000);
	$(".bigimg").animate({opacity:"1"},1000);
	$(".cttitle").animate({opacity:"1"},1000);
	$(".cttext").animate({opacity:"1"},1000);
	$(".ctline").animate({opacity:"1"},1000);



	scrt=$(".second").offset();
	console.log(scrt);

	$(window).scroll(function(){
		if (scrollTop=scrt)
		{
			$(".second").animate({opacity:"1"},1000, function(){
				$(".third").delay(800).animate({opacity:"1"},1000, function(){
					$(".fourth").delay(800).animate({opacity:"1"},1000, function(){
				});
			});
		});
		}
	});

});//doc