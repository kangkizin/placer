//free22.js

$(document).ready(function(){
	
	$(".perm img",this).mouseenter(function(){
		$(this).stop().animate({opacity:"0.8"});	
	}).mouseleave(function(){
		$(this).stop().animate({opacity:"1"});
	});
	
	$(".perm1").mouseenter(function(){
		$(".red1").stop().fadeIn();
	}).mouseleave(function(){
		$(".red1").stop().fadeOut();
	});

	$(".perm2").mouseenter(function(){
		$(".red2").stop().fadeIn();
	}).mouseleave(function(){
		$(".red2").stop().fadeOut();
	});

	$(".perm3").mouseenter(function(){
		$(".red3").stop().fadeIn();
	}).mouseleave(function(){
		$(".red3").stop().fadeOut();
	});

	$(".perm4").mouseenter(function(){
		$(".red4").stop().fadeIn();
	}).mouseleave(function(){
		$(".red4").stop().fadeOut();
	});


	$(".chair1").click(function(){
		$(".perm").fadeOut();
		$(".chairbox .chairr, .x, .contentsbox .chairr0").fadeIn();	
	});

	$(".desk1").click(function(){
		$(".perm").fadeOut();
		$(".chairbox .deskk1, .x, .contentsbox .deskk10").fadeIn();	
	});

	$(".light1").click(function(){
		$(".perm").fadeOut();
		$(".chairbox .lightt, .x, .contentsbox .lightt0").fadeIn();	
	});

	$(".desk2").click(function(){
		$(".perm").fadeOut();
		$(".chairbox .deskk2, .x, .contentsbox .deskk20").fadeIn();	
	});

	$(".x").click(function(){
		$(".x").fadeOut();
		$(".mi2").fadeOut();
		$(".mi3").fadeOut();
		$(".perm").removeAttr("style");
	});
		
	$(".bed").mouseenter(function(){
		$(".center .issue .bed img").stop().animate({opacity:"0.6"});
		$(".center .issue .bed .istext").stop().fadeIn();
	}).mouseleave(function(){
		$(".center .issue .bed img").stop().animate({opacity:"1"});
		$(".center .issue .bed .istext").removeAttr("style");
	});

	$(".live").mouseenter(function(){
		$(".center .issue .live img").stop().animate({opacity:"0.6"});
		$(".center .issue .live .istext").stop().fadeIn();
	}).mouseleave(function(){
		$(".center .issue .live img").stop().animate({opacity:"1"});
		$(".center .issue .live .istext").removeAttr("style");
	});

	$(".kitc").mouseenter(function(){
		$(".center .issue .kitc img").stop().animate({opacity:"0.6"});
		$(".center .issue .kitc .istext").stop().fadeIn();
	}).mouseleave(function(){
		$(".center .issue .kitc img").stop().animate({opacity:"1"});
		$(".center .issue .kitc .istext").removeAttr("style");
	});

	$(".stud").mouseenter(function(){
		$(".center .issue .stud img").stop().animate({opacity:"0.6"});
		$(".center .issue .stud .istext").stop().fadeIn();
	}).mouseleave(function(){
		$(".center .issue .stud img").stop().animate({opacity:"1"});
		$(".center .issue .stud .istext").removeAttr("style");
	});

	$(".kids").mouseenter(function(){
		$(".center .issue .kids img").stop().animate({opacity:"0.6"});
		$(".center .issue .kids .istext").stop().fadeIn();
	}).mouseleave(function(){
		$(".center .issue .kids img").stop().animate({opacity:"1"});
		$(".center .issue .kids .istext").removeAttr("style");
	});

});//doc