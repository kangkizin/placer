//free22.js

$(document).ready(function(){
	 
          //$("body").smoothWheel()
       
		
	$(".menu").click(function(){
		$(".bar1").css({opacity:"0"});
		$(".bar3").css({opacity:"0"});
		$(".bar2").css({transform: "rotate(-360deg) translate(0px, 0px)"});
		$(".allmenu").animate({right:"-45%"},1500);
		$(".close").fadeIn(1000);
		$(".allblack").delay(500).fadeIn(1000);
	});
		//var none= $(".bar2").css({transform: "rotate(-360deg) translate(0px, 0px)"})
		
	
	$(".close").click(function(){
		$(".close").fadeOut();
		$(".bar1").removeAttr("style");
		$(".bar3").removeAttr("style");
		$(".bar2").removeAttr("style");
		$(".allmenu").animate({right:"-100%"},1500);
		$(".allblack").delay(500).fadeOut(1000);
	});
	$(".allblack").click(function(){
		$(".close").fadeOut();
		$(".bar1").removeAttr("style");
		$(".bar3").removeAttr("style");
		$(".bar2").removeAttr("style");
		$(".allmenu").animate({right:"-100%"},1500);
		$(".allblack").delay(500).fadeOut(1000);
	});


	$(".gnb>.placehold").mouseenter(function(){
		$(".gnb>li:nth-child(2)>a").css({"border-bottom":"1px solid #fff",color:"#fff"});
		$(".plnb").stop().fadeIn();
	}).mouseleave(function(){
		$(".gnb>li:nth-child(2)>a").removeAttr("style");
		$(".plnb").stop().fadeOut();
	});

	$(window).scroll(function(){

			
			var topvar=$(document).scrollTop(); 
			var dd=$(document).height();
			//console.log(topvar, dd);

			if (topvar>=700)
			{
				$(".topkey").css({"opacity":"1"});
			}else{
				$(".topkey").css({"opacity":"0"});
			}//if

//			$("html, body").animate({
//				scrollTop
//			},1000);
		
	
		});//window scrollTop

		$(".topkey").click(function(){
			$("html, body").animate({
				scrollTop:0
			}, 1000,"swing");
		});
	
	$(".allmenu>.allmm .allmm2").mouseenter(function(){
		$(".allmenu>.allmm .allmm2 .plnb2").stop().slideDown();
	}).mouseleave(function(){
		$(".allmenu>.allmm .allmm2 .plnb2").stop().slideUp();
	});

	//--------------------------------------------------------------------
	$(".lotitle").click(function(){
		$(location).attr('href',"index.html"); 
	});

	$(".loginbox>li:nth-child(1)").click(function(){
		$(location).attr('href',"login.html"); 
	});

	$(".login, .p222").animate({opacity:"1"},2000);

	$(".loginbox>li:nth-child(2)").click(function(){
		$(location).attr('href',"join.html"); 
	});
});//doc