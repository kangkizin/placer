//kids.js

$(document).ready(function(){
	
	$(".section").animate({opacity:"1"},1500);

	$(".bdbox").click(function(){
		$(".special").stop().fadeToggle();
	});
	

	$(".section .rightbox .rtto img").click(function(){
			alert("체크한 상품들을 장바구니에 추가하시겠습니까?");
	});

	$(".rttext").click(function(){
		$(".section .centerbox .artleft .aa .ch1").stop().animate({opacity:"0"});
		$(".section .centerbox .artright .aa .ch1").stop().animate({opacity:"0"});
	});



	$(".section .centerbox .artleft .aa .img1").click(function(){
		//$(".section .centerbox .artleft .a1 .ch1").stop().animate({opacity:"1"});
		$(this).siblings(".ch1").stop().animate({opacity:"1"});
	});

	$(".section .centerbox .artright .aa .img1").click(function(){
		//$(".section .centerbox .artleft .a1 .ch1").stop().animate({opacity:"1"});
		$(this).siblings(".ch1").stop().animate({opacity:"1"});
	});

	$(".section .centerbox .artleft .aa .img1").mouseenter(function(){
		$(this).stop().animate({opacity:"0.6"});
		$(this).siblings(".pbox").stop().animate({opacity:"1"});
	}).mouseleave(function(){
		$(this).stop().animate({opacity:"1"});
		$(this).siblings(".pbox").stop().animate({opacity:"0"});
	});

	$(".section .centerbox .artright .aa .img1").mouseenter(function(){
		$(this).stop().animate({opacity:"0.6"});
		$(this).siblings(".pbox").stop().animate({opacity:"1"});
	}).mouseleave(function(){
		$(this).stop().animate({opacity:"1"});
		$(this).siblings(".pbox").stop().animate({opacity:"0"});
	});

	$(".loul>li:nth-child(1)").click(function(){
		$(location).attr('href',"login.html"); 
	});

	
});//doc