//study.js

$(document).ready(function(){
	$(".section .center").animate({opacity:"1"},2500);


	$(".gnb>.placehold").mouseenter(function(){
		$(".gnb>li:nth-child(2)>a").css({"border-bottom":"1px solid brown",color:"brown"});
		$(".plnb").stop().fadeIn();
	}).mouseleave(function(){
		$(".gnb>li:nth-child(2)>a").removeAttr("style");
		$(".plnb").stop().fadeOut();
	});

	$(window).scroll(function(){
		toop=$(document).scrollTop();
		console.log(toop);
		if (toop>=200)
		{
			$(".quick").animate({opacity:"1"},1500);
		}

		if (toop>=cc1-40)
		{
			$(".quick .qul li:nth-child(1)").css({background:"brown",color:"#fff"});
			$(".quick .qul li:nth-child(1)").siblings().removeAttr("style");
		}

		if (toop>=cc2-40)
		{
			$(".quick .qul li:nth-child(2)").css({background:"brown",color:"#fff"});
			$(".quick .qul li:nth-child(2)").siblings().removeAttr("style");
		}

		if (toop>=cc3-40)
		{
			$(".quick .qul li:nth-child(3)").css({background:"brown",color:"#fff"});
			$(".quick .qul li:nth-child(3)").siblings().removeAttr("style");
		}

		if (toop>=cc4-50)
		{
			$(".quick .qul li:nth-child(4)").css({background:"brown",color:"#fff"});
			$(".quick .qul li:nth-child(4)").siblings().removeAttr("style");
		}
	});

	$(function() {
                $("#gooey-v").gooeymenu({
                style: "vertical",
                vertical: {
                    menuItemPosition: "spaced",
                    direction: "up"
                }
              });
            });



	cc1=$(".section .center .desk .desktitle").offset().top;
	cc2=$(".section .center .book .desktitle").offset().top;
	cc3=$(".section .center .office .desktitle").offset().top;
	cc4=$(".section .center .cabi .desktitle").offset().top;

	$(".quick .qul li:nth-child(1)").click(function(){
		$(this).css({background:"brown",color:"#fff"});
		$(this).siblings().removeAttr("style");
		$("html, body").animate({
				scrollTop:cc1-40}, 1000,"swing");
	});

	$(".quick .qul li:nth-child(2)").click(function(){
		$(this).css({background:"brown",color:"#fff"});
		$(this).siblings().removeAttr("style");
		$("html, body").animate({
				scrollTop:cc2-40}, 1000,"swing");
	});

	$(".quick .qul li:nth-child(3)").click(function(){
		$(this).css({background:"brown",color:"#fff"});
		$(this).siblings().removeAttr("style");
		$("html, body").animate({
				scrollTop:cc3-40}, 1000,"swing");
	});

	$(".quick .qul li:nth-child(4)").click(function(){
		$(this).css({background:"brown",color:"#fff"});
		$(this).siblings().removeAttr("style");
		$("html, body").animate({
				scrollTop:cc4-50}, 1000,"swing");
	});


	$(".section .center .desk .tt1 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/a1.png").stop().fadeIn(300);
			});
			$(".section .center .desk .tt1 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ch1.png").stop().fadeIn(300);
		});
		$(".section .center .desk .tt1 p").css({"color":"black"});
	});

	$(".section .center .desk .tt2 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/a2.png").stop().fadeIn(300);
			});
			$(".section .center .desk .tt2 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ch2.png").stop().fadeIn(300);
		});
		$(".section .center .desk .tt2 p").css({"color":"black"});
	});

	$(".section .center .desk .tt3 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/a3.png").stop().fadeIn(300);
			});
			$(".section .center .desk .tt3 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ch3.png").stop().fadeIn(300);
		});
		$(".section .center .desk .tt3 p").css({"color":"black"});
	});

	$(".section .center .desk .tt4 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/a4.png").stop().fadeIn(300);
			});
			$(".section .center .desk .tt4 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ch4.png").stop().fadeIn(300);
		});
		$(".section .center .desk .tt4 p").css({"color":"black"});
	});

	$(".section .center .book .tt1 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/b1.png").stop().fadeIn(300);
			});
			$(".section .center .book .tt1 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/cl4.png").stop().fadeIn(300);
		});
		$(".section .center .book .tt1 p").css({"color":"black"});
	});

	$(".section .center .book .tt2 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/b2.png").stop().fadeIn(300);
			});
			$(".section .center .book .tt2 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/cl3.png").stop().fadeIn(300);
		});
		$(".section .center .book .tt2 p").css({"color":"black"});
	});

	$(".section .center .book .tt3 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/b3.png").stop().fadeIn(300);
			});
			$(".section .center .book .tt3 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/cl5.png").stop().fadeIn(300);
		});
		$(".section .center .book .tt3 p").css({"color":"black"});
	});

	$(".section .center .book .tt4 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/b4.png").stop().fadeIn(300);
			});
			$(".section .center .book .tt4 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/cl8.png").stop().fadeIn(300);
		});
		$(".section .center .book .tt4 p").css({"color":"black"});
	});

	$(".section .center .office .tt1 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/c1.png").stop().fadeIn(300);
			});
			$(".section .center .office .tt1 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ca2.png").stop().fadeIn(300);
		});
		$(".section .center .office .tt1 p").css({"color":"black"});
	});

	$(".section .center .office .tt2 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/c2.png").stop().fadeIn(300);
			});
			$(".section .center .office .tt2 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ca3.png").stop().fadeIn(300);
		});
		$(".section .center .office .tt2 p").css({"color":"black"});
	});

	$(".section .center .office .tt3 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/c3.png").stop().fadeIn(300);
			});
			$(".section .center .office .tt3 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ca6.png").stop().fadeIn(300);
		});
		$(".section .center .office .tt3 p").css({"color":"black"});
	});

	$(".section .center .office .tt4 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/c4.png").stop().fadeIn(300);
			});
			$(".section .center .office .tt4 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/ca8.png").stop().fadeIn(300);
		});
		$(".section .center .office .tt4 p").css({"color":"black"});
	});

	$(".section .center .cabi .tt1 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/d1.png").stop().fadeIn(300);
			});
			$(".section .center .cabi .tt1 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/dd1.png").stop().fadeIn(300);
		});
		$(".section .center .cabi .tt1 p").css({"color":"black"});
	});

	$(".section .center .cabi .tt2 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/d2.png").stop().fadeIn(300);
			});
			$(".section .center .cabi .tt2 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/dd2.png").stop().fadeIn(300);
		});
		$(".section .center .cabi .tt2 p").css({"color":"black"});
	});

	$(".section .center .cabi .tt3 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/d3.png").stop().fadeIn(300);
			});
			$(".section .center .cabi .tt3 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/dd3.png").stop().fadeIn(300);
		});
		$(".section .center .cabi .tt3 p").css({"color":"black"});
	});

	$(".section .center .cabi .tt4 img").mouseenter(function(){
			$(this).fadeOut(200,function(){
				$(this).attr("src","studyroom/d4.png").stop().fadeIn(300);
			});
			$(".section .center .cabi .tt4 p").css({"color":"brown"});
	}).mouseleave(function(){
		$(this).fadeOut(200,function(){
		$(this).attr("src","studyroom/dd4.png").stop().fadeIn(300);
		});
		$(".section .center .cabi .tt4 p").css({"color":"black"});
	});





});//doc