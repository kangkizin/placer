//free22.js

$(document).ready(function(){
	

	$(".chair1").click(function(){
		$(".mi").css({opacity:"0"});
		$(".chairbox .chairr, .x").fadeIn();	
	});

	$(".desk1").click(function(){
		$(".mi").css({opacity:"0"});
		$(".chairbox .deskk1, .x").fadeIn();	
	});

	$(".light1").click(function(){
		$(".mi").css({opacity:"0"});
		$(".chairbox .lightt, .x").fadeIn();	
	});

	$(".desk2").click(function(){
		$(".mi").css({opacity:"0"});
		$(".chairbox .deskk2, .x").fadeIn();	
	});

	$(".x").click(function(){
		$(".x").fadeOut();
		$(".mi2").fadeOut();
		$(".mi").removeAttr("style");
	});
		
	$(".menu").click(function(){
		$(".bar1").css({opacity:"0"});
		$(".bar3").css({opacity:"0"});
		$(".bar2").css({transform: "rotate(-360deg) translate(0px, 0px)"});
		$(".close").fadeIn(1000);
	});
		//var none= $(".bar2").css({transform: "rotate(-360deg) translate(0px, 0px)"})
		
	
	$(".close").click(function(){
		$(".close").fadeOut();
		$(".bar1").removeAttr("style");
		$(".bar3").removeAttr("style");
		$(".bar2").removeAttr("style");
	});
});//doc