//support.js

$(document).ready(function(){
	//$(".box1text, .box2text, .box3text").css({opacity:"0"});
	$(".section").animate({opacity:"1"},2000);
	

	$(".box1").mouseenter(function(){
		$(".qna").stop().fadeOut();
		$(".box1text").stop().animate({opacity:"1"});
	}).mouseleave(function(){
		$(".qna").stop().delay(400).fadeIn();
		$(".box1text").stop().animate({opacity:"0"});
	});

	$(".box2").mouseenter(function(){
		$(".ars").stop().fadeOut();
		$(".box2text").stop().animate({opacity:"1"});
	}).mouseleave(function(){
		$(".ars").stop().delay(400).fadeIn();
		$(".box2text").stop().animate({opacity:"0"});
	});

	$(".box3").mouseenter(function(){
		$(".oao").stop().fadeOut();
		$(".box3text").stop().animate({opacity:"1"});
	}).mouseleave(function(){
		$(".oao").stop().delay(400).fadeIn();
		$(".box3text").stop().animate({opacity:"0"});
	});
});//doc