//bed.js

$(document).ready(function(){
	$(".section .first .fp").animate({"opacity":"1"},3000);
	w=$(".slider").width();
	h=$(".slider").height();
	cnt=$(".item").length;
	cnt2=$(".section .center .slider .container .item").width();
	cnt3=$(".section .center .slider .container .item").css("margin-left");
	page=0;
	console.log(cnt2);



	function moveone(){
		$(".container").animate({left:page*-(cnt2+20)}); //*2*
	};//func

	if (matchMedia("screen and (max-width: 1280px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+50)}); //*2*
			};//func
		} 
	if (matchMedia("screen and (max-width: 1200px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+90)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 959px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+180)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 50em)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+270)}); //*2*
			};//func
		} 
	

	if (matchMedia("screen and (max-width: 768px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+180)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 667px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+230)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 40em)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+240)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 576px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+280)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 480px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+270)}); //*2*
			};//func
		} 
	
	if (matchMedia("screen and (max-width: 375px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+207)}); //*2*
			};//func
		} 
	if (matchMedia("screen and (max-width: 360px)").matches) {
	function moveone(){
			$(".container").animate({left:page*-(cnt2+210)}); //*2*
			};//func
		}

	
	//setInterval(function(){moveone();},1000);
		
			$(".next").click(function(){
				if (cnt-4>page) //if(page<cnt-1) //*3*
				{
					page++;
					//$(".container").animate({left:page*-w});
					console.log(page);
				} else{
					page=0;
					//$(".container").animate({left:page*-w});
				}//if	
				//$(".container").animate({left:page*-w}); //위에 2개 공통 적인 부분
				moveone();//함수로 호출가능
			});//next

			$(".prev").click(function(){
				if (page>0)
				{
					page--;
					
				}//else {
				//	page=cnt-4; //*4*
				//}//if
				//$(".container").animate({left:page*-w});
				moveone();//함수로 호출가능
			});//prev
		pro1=$(".chtitle1").offset().top;
		pro2=$(".chtitle2").offset().top;
		pro3=$(".chtitle3").offset().top;
		pro4=$(".chtitle4").offset().top;
		console.log(pro4);
		
		$(window).scroll(function(){
			var topp=$(document).scrollTop();
			console.log();
			if (topp>=1600)
			{
				$(".section .center .product .prul").addClass("pofixed");
			}else{
				$(".section .center .product .prul").removeClass("pofixed");
			}

			if (topp>=1000)
			{
				$(".smsm").animate({"opacity":"1"});
			}

			if (topp>=pro1-169)
			{
				$(".section .center .product .prul li:nth-child(2)").css({"background":"brown","color":"#fff"});
				$(".section .center .product .prul li:nth-child(2)").siblings().removeAttr("style");
			}

			if (topp>=pro2-173)
			{
				$(".section .center .product .prul li:nth-child(3)").css({"background":"brown","color":"#fff"});
				$(".section .center .product .prul li:nth-child(3)").siblings().removeAttr("style");
			}

			if (topp>=pro3-177)
			{
				$(".section .center .product .prul li:nth-child(4)").css({"background":"brown","color":"#fff"});
				$(".section .center .product .prul li:nth-child(4)").siblings().removeAttr("style");
			}

			if (topp>=pro4-171)
			{
				$(".section .center .product .prul li:nth-child(5)").css({"background":"brown","color":"#fff"});
				$(".section .center .product .prul li:nth-child(5)").siblings().removeAttr("style");
			}
		});//scroll

		$(".section .center .product .prul li:nth-child(2)").click(function(){
				
				$(this).css({"background":"brown","color":"#fff"});
				$(this).siblings().removeAttr("style");
				$("html, body").animate({
				scrollTop:pro1-169}, 1000,"swing");
			});

		$(".section .center .product .prul li:nth-child(3)").click(function(){
				$(this).css({"background":"brown","color":"#fff"});
				$(this).siblings().removeAttr("style");
				$("html, body").animate({
				scrollTop:pro2-173}, 1000,"swing");
			});

		$(".section .center .product .prul li:nth-child(4)").click(function(){
				$(this).css({"background":"brown","color":"#fff"});
				$(this).siblings().removeAttr("style");
				$("html, body").animate({
				scrollTop:pro3-177}, 1000,"swing");
			});

		$(".section .center .product .prul li:nth-child(5)").click(function(){
				$(this).css({"background":"brown","color":"#fff"});
				$(this).siblings().removeAttr("style");
				$("html, body").animate({
				scrollTop:pro4-171}, 1000,"swing");
			});

		 $(function() {
                $("#gooey-v").gooeymenu({
                style: "vertical",
                vertical: {
                    menuItemPosition: "spaced",
                    direction: "up"
                }
              });
            });
});//doc