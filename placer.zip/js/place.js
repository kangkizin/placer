//place.js

$(document).ready(function(){
	

	$(window).scroll(function(){
			var topp=$(document).scrollTop(); 
			
			if (topp>=600)
			{
				$(".bd1").animate({"opacity":"1"},1000, function(){
					$(".bd2").animate({"opacity":"1"},1000, function(){
						$(".bd3").animate({"opacity":"1"},1000, function(){
							$(".bd4").animate({"opacity":"1"},1000, function(){
								$(".bd5").animate({"opacity":"1"},1000);
							});
						});
					});
				});
			}
		
		});//$(window).scroll
		pro1=$(".center .new .newtitle1").offset().top;
		$(".placetitle .button1").click(function(){
			
				$("html, body").animate({
				scrollTop:610}, 1000,"swing");
				
			});
});//doc