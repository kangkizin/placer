//kitchen.js

$(document).ready(function(){
	$(".centertitle, .showbox, .bottombox, .smsm").animate({opacity:"1"},3000);

	$(".gnb>.placehold").mouseenter(function(){
		$(".gnb>li:nth-child(2)>a").css({"border-bottom":"1px solid brown",color:"brown"});
		$(".plnb").stop().fadeIn();
	}).mouseleave(function(){
		$(".gnb>li:nth-child(2)>a").removeAttr("style");
		$(".plnb").stop().fadeOut();
	});

	$(function() {
                $("#gooey-v").gooeymenu({
                style: "vertical",
                vertical: {
                    menuItemPosition: "spaced",
                    direction: "up"
                }
              });
            });
	
	
		$(".imgg").click(function(){
			 view1=$(this).attr("src");
			 console.log(view1);
			$(".imgg1").attr("src",view1);
		});
	
	//----------------------------------------------------------------------------
		$(".b1").click(function(){
			alert("정말로 구입하시겠습니까?");
		});

		$(".b2").click(function(){
			alert("장바구니에 추가하시겠습니까?");
		});
	//------------------------------------------------------------------------------
	$(".bt").mouseenter(function(){
		$(this).stop().animate({opacity:"1"},1000);
	}).mouseleave(function(){
		$(this).stop().animate({opacity:"0.4"},1000);
	});

	scream=$(".imgg1").offset().top;
	//console.log(scream);
	$(".bt").click(function(){
		$("html, body").stop().animate({
			scrollTop:scream
		},1000);
	});
	
	$(".bt1").click(function(){
		$(".imgg1").attr("src","kitchen/bd3.png");
		$(".imgg2").attr("src","kitchen/bd3_1.png");
		$(".imgg3").attr("src","kitchen/bd3.png");
		$(".imgg4").attr("src","kitchen/bd3_2.png");
		$(".righttitle").text("브로슈 4인/6인 대리석 식탁");
		$(".righttitle2").text("Broshe Marble Table");
		$(".price").text("288,000won");

		
	});

	$(".bt2").click(function(){
		$(".imgg1").attr("src","kitchen/ch5.png");
		$(".imgg2").attr("src","kitchen/ch5_1.png");
		$(".imgg3").attr("src","kitchen/ch5.png");
		$(".imgg4").attr("src","kitchen/ch5_2.png");
		$(".righttitle").text("라센 우드슬랩 통원목 식탁");
		$(".righttitle2").text("Lassen Woodslap");
		$(".price").text("299,000won");
	});

	$(".bt3").click(function(){
		$(".imgg1").attr("src","kitchen/bd4.png");
		$(".imgg2").attr("src","kitchen/bt4_1.png");
		$(".imgg3").attr("src","kitchen/bd4.png");
		$(".imgg4").attr("src","kitchen/bt4_2.png");
		$(".righttitle").text("라움 엔젤 화이트식탁");
		$(".righttitle2").text("Laum Angel White");
		$(".price").text("239,000won");
	});

	$(".ct1").click(function(){
		$(".imgg1").attr("src","kitchen/bd2.png");
		$(".imgg2").attr("src","kitchen/bd2_1.png");
		$(".imgg3").attr("src","kitchen/bd2.png");
		$(".imgg4").attr("src","kitchen/bd2_2.png");
		$(".righttitle").text("에펠의자 고급형");
		$(".righttitle2").text("Eiffel chair High-Q");
		$(".price").text("29,900won");
	});

	$(".ct2").click(function(){
		$(".imgg1").attr("src","kitchen/ca1.png");
		$(".imgg2").attr("src","kitchen/ca1_1.png");
		$(".imgg3").attr("src","kitchen/ca1.png");
		$(".imgg4").attr("src","kitchen/ca1_2.png");
		$(".righttitle").text("앤슨 인테리어 원목의자");
		$(".righttitle2").text("Anson Interior Solid");
		$(".price").text("79,900won");
	});

	$(".ct3").click(function(){
		$(".imgg1").attr("src","kitchen/ca3.png");
		$(".imgg2").attr("src","kitchen/ca3_1.png");
		$(".imgg3").attr("src","kitchen/ca3.png");
		$(".imgg4").attr("src","kitchen/ca3_2.png");
		$(".righttitle").text("파이의자 3color");
		$(".righttitle2").text("Pie Chair 3color");
		$(".price").text("32,900won");
	});

	$(".dt1").click(function(){
		$(".imgg1").attr("src","kitchen/cl8.png");
		$(".imgg2").attr("src","kitchen/cl8_1.png");
		$(".imgg3").attr("src","kitchen/cl8.png");
		$(".imgg4").attr("src","kitchen/cl8_2.png");
		$(".righttitle").text("레마 카페장 600폭");
		$(".righttitle2").text("Rema Cafe 600width");
		$(".price").text("279,000won");
	});

	$(".dt2").click(function(){
		$(".imgg1").attr("src","kitchen/cl4.png");
		$(".imgg2").attr("src","kitchen/cl4_1.png");
		$(".imgg3").attr("src","kitchen/cl4.png");
		$(".imgg4").attr("src","kitchen/cl4_2.png");
		$(".righttitle").text("루이스 광파 주방수납장");
		$(".righttitle2").text("Lewis Lightwave");
		$(".price").text("105,000won");
	});

	$(".dt3").click(function(){
		$(".imgg1").attr("src","kitchen/cl2.png");
		$(".imgg2").attr("src","kitchen/cl2_1.png");
		$(".imgg3").attr("src","kitchen/cl2.png");
		$(".imgg4").attr("src","kitchen/cl2_2.png");
		$(".righttitle").text("알렉스 렌지대 세트");
		$(".righttitle2").text("Alex Range Set");
		$(".price").text("176,700won");
	});
});//doc