//location.js



$(document).ready(function(){
		$(".section, .b1, .bg2").animate({opacity:"1"},2000);

		$(window).scroll(function(){
			var topp=$(document).scrollTop(); 
			var scroll=$(".inner").offset().top;
			

			if (topp>=750)
			{
				$(".inner img").animate({"opacity":"1"},2500);
				$(".intext").css({"display":"block"});


			}

			if (topp>=500)
			{
				$(".bg2").css({"display":"block"});
			}
		});


		$(".button1").click(function(){
			
			$(this).addClass("ing");
			$("#hwa1").show();
			$("#hwa2, #hwa3, #hwa4").hide();
		});

		$(".button2").click(function(){
			
			$(this).addClass("ing");
			$("#hwa2").show();
			$("#hwa1, #hwa3, #hwa4").hide();
		});

		$(".button3").click(function(){
			
			$(this).addClass("ing");
			$("#hwa3").show();
			$("#hwa1, #hwa2, #hwa4").hide();
		});

		$(".button4").click(function(){
			
			$(this).addClass("ing");
			$("#hwa4").show();
			$("#hwa1, #hwa2, #hwa3").hide();
		});
	
		$(".rightbt").click(function(){
			$(".comeon").slideToggle();
		});
});//doc